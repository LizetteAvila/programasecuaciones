e4:-
    display('Introduce A: '),
    read(A),
    display('Introduce B: '),
    read(B),
    display('Introduce C: '),
    read(C),
    display('Introduce D: '),
    read(D),
    Y is ((D+A*B)/4)/((5*C)/(3*A+C^3)),
    display('El valor de Y es: '),
    display(Y).
