secciona:-display('Introduce A'),
	read(A),
	display('Introduce B'),
	read(B),
	display('Introduce C'),
	read(C),
        display('Introduce d'),
        read(D),

        Y is (A-5*B^3)+(3*C- D),

	display('El resultado es: '),
	display(Y).









