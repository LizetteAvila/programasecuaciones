H:-Display('Ingresa el valor de A: '),
      read(A),
      display('Ingresa el valor de B: '),
      read(B),
      display('Ingresa el valor de C: '),
      read(C),
      display('Ingresa el valor de D: '),
      read(D),
      display('Ingresa el valor de E: '),
      read(E),
       display('Ingresa el valor de F: '),
      read(F),


      Y is (CD+EA)(B-D/C-D) + A^2/F,
      display('El valor de Y es: '),
      display(Y).
