h3:-
    display('Introduce A: '),
    read(A),
    display('Introduce B: '),
    read(B),
    display('Introduce C: '),
    read(C),
    display('Introduce D: '),
    read(D),
    Y is 8*A*B^2-(2*C+3)/(D+7)^2+1/3,
    display('El valor de Y es: '),
    display(Y).
