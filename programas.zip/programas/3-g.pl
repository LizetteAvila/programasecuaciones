g3:-
    display('Introduce A: '),
    read(A),
    display('Introduce B: '),
    read(B),
    display('Introduce E: '),
    read(E),
    display('Introduce D: '),
    read(D),
    Y is (3-D*E)/(4-5*A/D)+7/(A-B^2),
    display('El valor de Y es: '),
    display(Y).
