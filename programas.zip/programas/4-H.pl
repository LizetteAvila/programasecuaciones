H2:-Display('Ingresa el valor de A: '),
      read(A),
      display('Ingresa el valor de B: '),
      read(B),
      display('Ingresa el valor de C: '),
      read(C),
      display('Ingresa el valor de D: '),
      read(D),
      display('Ingresa el valor de E: '),
      read(E),
      display('Ingresa el valor de F: '),
      read(F),
      display('Ingresa el valor de G: '),
      read(G),
      display('Ingresa el valor de H: '),
      read(H),



      Y is (((E+C*D)^4)*(C-2))/(F/G*A-H)),
      display('El valor de Y es: '),
      display(Y).
