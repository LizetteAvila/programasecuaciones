G:-Display('Ingresa el valor de A: '),
      read(A),
      display('Ingresa el valor de B: '),
      read(B),
      display('Ingresa el valor de C: '),
      read(C),
      display('Ingresa el valor de D: '),
      read(D),
      display('Ingresa el valor de E: '),
      read(E),


      Y is (A+B-D^4)^5(A*B)+ C/(D+E),
      display('El valor de Y es: '),
      display(Y).
